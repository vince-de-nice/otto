import 'package:otto/entities/nmea/derived.dart';

class Aircraft with MoreData, DerivedInfo, AircraftState {}
