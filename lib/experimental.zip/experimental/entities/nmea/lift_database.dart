class LiftDatabase {
  final data = List.filled(36, 0);
  void clear() {
    data.fillRange(0, 35, 0);
  }
}
